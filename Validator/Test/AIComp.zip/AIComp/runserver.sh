java -jar ./"Java Library"/BotRampage.jar $@
