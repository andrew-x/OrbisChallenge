sh runserver.sh -n 1 &
sleep 4
sh compile.sh
sh runclient.sh
